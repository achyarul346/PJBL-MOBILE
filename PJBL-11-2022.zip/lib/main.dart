import 'package:flutter/material.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedhomepagewidget/GeneratedHomepageWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedloginwidget/GeneratedLoginWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generateddaftarwidget1/GeneratedDaftarWidget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/GeneratedProdukyamahaWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget2/GeneratedProdukyamahaWidget2.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget/GeneratedProdukhondaWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/GeneratedProdukhondaWidget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/GeneratedProduksuzukiWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/GeneratedProduksuzukiWidget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukkawasakiwidget/GeneratedProdukkawasakiWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukkawasakiwidget1/GeneratedProdukkawasakiWidget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedubahprofilwidget/GeneratedUbahprofilWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedubahprofiladminwidget/GeneratedubahprofiladminWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprofilkamuwidget/GeneratedProfilkamuWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprofiladminwidget/GeneratedProfiladminWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedspesifikasiwidget/GeneratedSpesifikasiWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedpembayaranwidget1/GeneratedPembayaranWidget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedakhirwidget/GeneratedAkhirWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedellipse1widget4/GeneratedEllipse1Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedloginadminwidget/GeneratedLoginadminWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generateddashboardwidget/GeneratedDashboardWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generateddaftarbestsellerwidget/GeneratedDaftarbestsellerWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generateddaftarprodukwidget/GeneratedDaftarprodukWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generateddashboardwidget2/GeneratedDashboardWidget2.dart';
import 'package:flutterapp/pjbl_11_2022app/generatediconpersonwidget3/GeneratediconpersonWidget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedrectangle24widget2/GeneratedRectangle24Widget2.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedrectangle22widget4/GeneratedRectangle22Widget4.dart';

void main() {
  runApp(PJBL_11_2022App());
}

class PJBL_11_2022App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedHomepageWidget',
      routes: {
        '/GeneratedHomepageWidget': (context) => GeneratedHomepageWidget(),
        '/GeneratedLoginWidget': (context) => GeneratedLoginWidget(),
        '/GeneratedDaftarWidget1': (context) => GeneratedDaftarWidget1(),
        '/GeneratedProdukyamahaWidget': (context) =>
            GeneratedProdukyamahaWidget(),
        '/GeneratedProdukyamahaWidget2': (context) =>
            GeneratedProdukyamahaWidget2(),
        '/GeneratedProdukhondaWidget': (context) =>
            GeneratedProdukhondaWidget(),
        '/GeneratedProdukhondaWidget1': (context) =>
            GeneratedProdukhondaWidget1(),
        '/GeneratedProduksuzukiWidget': (context) =>
            GeneratedProduksuzukiWidget(),
        '/GeneratedProduksuzukiWidget1': (context) =>
            GeneratedProduksuzukiWidget1(),
        '/GeneratedProdukkawasakiWidget': (context) =>
            GeneratedProdukkawasakiWidget(),
        '/GeneratedProdukkawasakiWidget1': (context) =>
            GeneratedProdukkawasakiWidget1(),
        '/GeneratedUbahprofilWidget': (context) => GeneratedUbahprofilWidget(),
        '/GeneratedubahprofiladminWidget': (context) =>
            GeneratedubahprofiladminWidget(),
        '/GeneratedProfilkamuWidget': (context) => GeneratedProfilkamuWidget(),
        '/GeneratedProfiladminWidget': (context) =>
            GeneratedProfiladminWidget(),
        '/GeneratedSpesifikasiWidget': (context) =>
            GeneratedSpesifikasiWidget(),
        '/GeneratedPembayaranWidget1': (context) =>
            GeneratedPembayaranWidget1(),
        '/GeneratedAkhirWidget': (context) => GeneratedAkhirWidget(),
        '/GeneratedEllipse1Widget4': (context) => GeneratedEllipse1Widget4(),
        '/GeneratedLoginadminWidget': (context) => GeneratedLoginadminWidget(),
        '/GeneratedDashboardWidget': (context) => GeneratedDashboardWidget(),
        '/GeneratedDaftarbestsellerWidget': (context) =>
            GeneratedDaftarbestsellerWidget(),
        '/GeneratedDaftarprodukWidget': (context) =>
            GeneratedDaftarprodukWidget(),
        '/GeneratedDashboardWidget2': (context) => GeneratedDashboardWidget2(),
        '/GeneratediconpersonWidget3': (context) =>
            GeneratediconpersonWidget3(),
        '/GeneratedRectangle24Widget2': (context) =>
            GeneratedRectangle24Widget2(),
        '/GeneratedRectangle22Widget4': (context) =>
            GeneratedRectangle22Widget4(),
      },
    );
  }
}
