import 'package:flutter/material.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle60Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle64Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle75Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle23Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedLine14Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle74Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedLine15Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedALLNEWSATRIAFF150Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedDetailWidget24.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/Generated17735000Widget2.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle61Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedLine16Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedGIXXERSF250Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedLine26Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/Generated18913000Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/Generated30511000Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedLine18Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle68Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedLine24Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedLine22Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedDetailWidget29.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedLine13Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/Generated28158000Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedLine21Widget4.dart';
import 'package:flutterapp/helpers/transform/transform.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle18Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle66Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedGSXR150Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle67Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle79Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedLine20Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/Generated34231000Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/Generated49890000Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedDetailWidget28.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle72Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedDetailWidget25.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle20Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedGEAR125Widget2.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedLine25Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle76Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle62Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedDetailWidget26.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle16Widget15.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedLine19Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle17Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle70Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle16Widget14.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle71Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedLine23Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle69Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle78Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedGroupWidget7.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle63Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle77Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle59Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedADDRESSFIWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle73Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle22Widget2.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle16Widget13.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedProdukSuzukiWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedGSXS150Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle65Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedDetailWidget27.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedLine17Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedRectangle21Widget2.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget/generated/GeneratedVectorWidget27.dart';

/* Frame produk suzuki
    Autogenerated by FlutLab FTF Generator
  */
class GeneratedProduksuzukiWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Material(
        child: ClipRRect(
      borderRadius: BorderRadius.circular(20.0),
      child: Container(
        width: 360.0,
        height: 640.0,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20.0),
        ),
        child: Stack(
            fit: StackFit.expand,
            alignment: Alignment.center,
            overflow: Overflow.visible,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(20.0),
                child: Container(
                  color: Color.fromARGB(255, 255, 255, 255),
                ),
              ),
              Positioned(
                left: 30.0,
                top: 39.0,
                right: null,
                bottom: null,
                width: 320.0,
                height: 42.0,
                child: GeneratedRectangle16Widget13(),
              ),
              Positioned(
                left: 35.0,
                top: 15.0,
                right: null,
                bottom: null,
                width: 35.0,
                height: 31.0,
                child: GeneratedRectangle16Widget14(),
              ),
              Positioned(
                left: 36.0,
                top: 15.0,
                right: null,
                bottom: null,
                width: 46.754676818847656,
                height: 1.0,
                child: GeneratedLine13Widget4(),
              ),
              Positioned(
                left: 70.0,
                top: 15.0,
                right: null,
                bottom: null,
                width: 46.754676818847656,
                height: 1.0,
                child: GeneratedLine14Widget4(),
              ),
              Positioned(
                left: 53.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle16Widget15(),
              ),
              Positioned(
                left: 53.0,
                top: 90.0,
                right: null,
                bottom: null,
                width: 179.0,
                height: 32.0,
                child: GeneratedProdukSuzukiWidget(),
              ),
              Positioned(
                left: 201.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle17Widget5(),
              ),
              Positioned(
                left: 53.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle18Widget5(),
              ),
              Positioned(
                left: 53.0,
                top: 227.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle59Widget4(),
              ),
              Positioned(
                left: 53.0,
                top: 247.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle74Widget4(),
              ),
              Positioned(
                left: 53.0,
                top: 394.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle64Widget4(),
              ),
              Positioned(
                left: 54.0,
                top: 414.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle76Widget4(),
              ),
              Positioned(
                left: 201.0,
                top: 227.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle61Widget4(),
              ),
              Positioned(
                left: 201.0,
                top: 247.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle75Widget4(),
              ),
              Positioned(
                left: 201.0,
                top: 394.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle66Widget4(),
              ),
              Positioned(
                left: 201.0,
                top: 414.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle77Widget4(),
              ),
              Positioned(
                left: 53.0,
                top: 560.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle69Widget4(),
              ),
              Positioned(
                left: 54.0,
                top: 580.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle78Widget4(),
              ),
              Positioned(
                left: 201.0,
                top: 560.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle72Widget4(),
              ),
              Positioned(
                left: 201.0,
                top: 580.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle79Widget4(),
              ),
              Positioned(
                left: 83.0,
                top: 268.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle60Widget4(),
              ),
              Positioned(
                left: 84.0,
                top: 435.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle65Widget4(),
              ),
              Positioned(
                left: 231.0,
                top: 268.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle62Widget4(),
              ),
              Positioned(
                left: 232.0,
                top: 435.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle67Widget4(),
              ),
              Positioned(
                left: 84.0,
                top: 601.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle70Widget4(),
              ),
              Positioned(
                left: 231.0,
                top: 601.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle73Widget4(),
              ),
              Positioned(
                left: 201.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle63Widget4(),
              ),
              Positioned(
                left: 53.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle68Widget4(),
              ),
              Positioned(
                left: 201.0,
                top: 456.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle71Widget4(),
              ),
              Positioned(
                left: 54.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 140.71603393554688,
                height: 1.0,
                child: GeneratedLine15Widget4(),
              ),
              Positioned(
                left: 153.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 140.7160186767578,
                height: 1.0,
                child: GeneratedLine16Widget4(),
              ),
              Positioned(
                left: 201.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine17Widget4(),
              ),
              Positioned(
                left: 301.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine18Widget4(),
              ),
              Positioned(
                left: 53.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine19Widget4(),
              ),
              Positioned(
                left: 169.0,
                top: 288.0,
                right: null,
                bottom: null,
                width: 140.71603393554688,
                height: 1.0,
                child: GeneratedLine20Widget4(),
              ),
              Positioned(
                left: 201.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine21Widget4(),
              ),
              Positioned(
                left: 301.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 141.41864013671875,
                height: 1.0,
                child: GeneratedLine22Widget4(),
              ),
              Positioned(
                left: 53.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine23Widget4(),
              ),
              Positioned(
                left: 153.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 140.7160186767578,
                height: 1.0,
                child: GeneratedLine24Widget4(),
              ),
              Positioned(
                left: 301.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 140.7160186767578,
                height: 1.0,
                child: GeneratedLine25Widget4(),
              ),
              Positioned(
                left: 201.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine26Widget4(),
              ),
              Positioned(
                left: 0.0,
                top: 0.0,
                right: 0.0,
                bottom: 0.0,
                width: null,
                height: null,
                child: LayoutBuilder(builder:
                    (BuildContext context, BoxConstraints constraints) {
                  double percentWidth = 0.05277777777777778;
                  double scaleX = (constraints.maxWidth * percentWidth) / 19.0;

                  double percentHeight = 0.0296875;
                  double scaleY =
                      (constraints.maxHeight * percentHeight) / 19.0;

                  return Stack(children: [
                    TransformHelper.translateAndScale(
                        translateX: constraints.maxWidth * 0.15,
                        translateY: constraints.maxHeight * 0.078125,
                        translateZ: 0,
                        scaleX: scaleX,
                        scaleY: scaleY,
                        scaleZ: 1,
                        child: GeneratedVectorWidget27())
                  ]);
                }),
              ),
              Positioned(
                left: 54.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle20Widget5(),
              ),
              Positioned(
                left: 202.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle21Widget2(),
              ),
              Positioned(
                left: 54.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle22Widget2(),
              ),
              Positioned(
                left: 201.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle23Widget4(),
              ),
              Positioned(
                left: 215.0,
                top: 559.0,
                right: null,
                bottom: null,
                width: 73.0,
                height: 17.0,
                child: GeneratedADDRESSFIWidget(),
              ),
              Positioned(
                left: 234.0,
                top: 600.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget24(),
              ),
              Positioned(
                left: 87.0,
                top: 600.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget25(),
              ),
              Positioned(
                left: 218.0,
                top: 579.0,
                right: null,
                bottom: null,
                width: 72.0,
                height: 20.0,
                child: Generated18913000Widget(),
              ),
              Positioned(
                left: 69.0,
                top: 579.0,
                right: null,
                bottom: null,
                width: 76.0,
                height: 20.0,
                child: Generated49890000Widget(),
              ),
              Positioned(
                left: 75.0,
                top: 225.0,
                right: null,
                bottom: null,
                width: 60.0,
                height: 17.0,
                child: GeneratedGEAR125Widget2(),
              ),
              Positioned(
                left: 205.0,
                top: 228.0,
                right: null,
                bottom: null,
                width: 95.0,
                height: 12.0,
                child: GeneratedALLNEWSATRIAFF150Widget(),
              ),
              Positioned(
                left: 71.0,
                top: 246.0,
                right: null,
                bottom: null,
                width: 71.0,
                height: 20.0,
                child: Generated17735000Widget2(),
              ),
              Positioned(
                left: 218.0,
                top: 246.0,
                right: null,
                bottom: null,
                width: 73.0,
                height: 20.0,
                child: Generated28158000Widget(),
              ),
              Positioned(
                left: 86.0,
                top: 267.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget26(),
              ),
              Positioned(
                left: 234.0,
                top: 267.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget27(),
              ),
              Positioned(
                left: 73.0,
                top: 393.0,
                right: null,
                bottom: null,
                width: 66.0,
                height: 20.0,
                child: GeneratedGSXS150Widget(),
              ),
              Positioned(
                left: 59.0,
                top: 559.0,
                right: null,
                bottom: null,
                width: 89.0,
                height: 17.0,
                child: GeneratedGIXXERSF250Widget(),
              ),
              Positioned(
                left: 220.0,
                top: 393.0,
                right: null,
                bottom: null,
                width: 66.0,
                height: 20.0,
                child: GeneratedGSXR150Widget(),
              ),
              Positioned(
                left: 70.0,
                top: 414.0,
                right: null,
                bottom: null,
                width: 72.0,
                height: 20.0,
                child: Generated30511000Widget(),
              ),
              Positioned(
                left: 216.0,
                top: 413.0,
                right: null,
                bottom: null,
                width: 74.0,
                height: 20.0,
                child: Generated34231000Widget(),
              ),
              Positioned(
                left: 86.0,
                top: 434.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget28(),
              ),
              Positioned(
                left: 234.0,
                top: 434.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget29(),
              ),
              Positioned(
                left: 0.0,
                top: 0.0,
                right: 0.0,
                bottom: 0.0,
                width: null,
                height: null,
                child: LayoutBuilder(builder:
                    (BuildContext context, BoxConstraints constraints) {
                  final double width =
                      constraints.maxWidth * 0.06944444444444445;

                  final double height = constraints.maxHeight * 0.0390625;

                  return Stack(children: [
                    TransformHelper.translate(
                        x: constraints.maxWidth * 0.013888888888888888,
                        y: constraints.maxHeight * 0.021875,
                        z: 0,
                        child: Container(
                          width: width,
                          height: height,
                          child: GeneratedGroupWidget7(),
                        ))
                  ]);
                }),
              )
            ]),
      ),
    ));
  }
}
