import 'package:flutter/material.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle68Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle62Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedProdukyamahaWidget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle60Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedMT25Widget.dart';
import 'package:flutterapp/helpers/transform/transform.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle65Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedDetailWidget2.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedDetailWidget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle79Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedMXKING150Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle24Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle20Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/Generated26755000Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedLine15Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle59Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedLine14Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedVectorWidget15.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle75Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle72Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedLine19Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedDetailWidget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle16Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedLine17Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle76Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle67Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedLine16Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedGEAR125Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/Generated67760000Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle71Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle22Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle70Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedLine25Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedR25Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle77Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle66Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle63Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle16Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle78Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedLine18Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedLine20Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle61Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/Generated103000000Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedDetailWidget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedLine24Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle18Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle73Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/Generated58725000Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle16Widget2.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle21Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedLine23Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedDetailWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/Generated17735000Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedLine21Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedDetailWidget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle23Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/Generated25180000Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedLine26Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle69Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedLine22Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle64Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle74Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedLine13Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedYZ250XWidget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedALLNEWAEROX155Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedGroupWidget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukyamahawidget/generated/GeneratedRectangle17Widget1.dart';

/* Frame produk yamaha
    Autogenerated by FlutLab FTF Generator
  */
class GeneratedProdukyamahaWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Material(
        child: ClipRRect(
      borderRadius: BorderRadius.circular(20.0),
      child: Container(
        width: 360.0,
        height: 640.0,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20.0),
        ),
        child: Stack(
            fit: StackFit.expand,
            alignment: Alignment.center,
            overflow: Overflow.visible,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(20.0),
                child: Container(
                  color: Color.fromARGB(255, 255, 255, 255),
                ),
              ),
              Positioned(
                left: 20.0,
                top: 40.0,
                right: null,
                bottom: null,
                width: 320.0,
                height: 42.0,
                child: GeneratedRectangle16Widget1(),
              ),
              Positioned(
                left: 35.0,
                top: 15.0,
                right: null,
                bottom: null,
                width: 35.0,
                height: 31.0,
                child: GeneratedRectangle16Widget2(),
              ),
              Positioned(
                left: 36.0,
                top: 15.0,
                right: null,
                bottom: null,
                width: 46.754676818847656,
                height: 1.0,
                child: GeneratedLine13Widget(),
              ),
              Positioned(
                left: 70.0,
                top: 15.0,
                right: null,
                bottom: null,
                width: 46.754676818847656,
                height: 1.0,
                child: GeneratedLine14Widget(),
              ),
              Positioned(
                left: 53.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle16Widget3(),
              ),
              Positioned(
                left: 54.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle20Widget1(),
              ),
              Positioned(
                left: 54.0,
                top: 90.0,
                right: null,
                bottom: null,
                width: 192.0,
                height: 32.0,
                child: GeneratedProdukyamahaWidget1(),
              ),
              Positioned(
                left: 201.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle17Widget1(),
              ),
              Positioned(
                left: 53.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle18Widget1(),
              ),
              Positioned(
                left: 53.0,
                top: 227.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle59Widget(),
              ),
              Positioned(
                left: 53.0,
                top: 247.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle74Widget(),
              ),
              Positioned(
                left: 53.0,
                top: 394.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle64Widget(),
              ),
              Positioned(
                left: 54.0,
                top: 414.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle76Widget(),
              ),
              Positioned(
                left: 201.0,
                top: 227.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle61Widget(),
              ),
              Positioned(
                left: 211.0,
                top: 228.0,
                right: null,
                bottom: null,
                width: 82.0,
                height: 12.0,
                child: GeneratedALLNEWAEROX155Widget(),
              ),
              Positioned(
                left: 201.0,
                top: 247.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle75Widget(),
              ),
              Positioned(
                left: 217.0,
                top: 246.0,
                right: null,
                bottom: null,
                width: 74.0,
                height: 20.0,
                child: Generated26755000Widget(),
              ),
              Positioned(
                left: 201.0,
                top: 394.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle66Widget(),
              ),
              Positioned(
                left: 201.0,
                top: 414.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle77Widget(),
              ),
              Positioned(
                left: 53.0,
                top: 560.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle69Widget(),
              ),
              Positioned(
                left: 79.0,
                top: 559.0,
                right: null,
                bottom: null,
                width: 54.0,
                height: 20.0,
                child: GeneratedYZ250XWidget(),
              ),
              Positioned(
                left: 54.0,
                top: 580.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle78Widget(),
              ),
              Positioned(
                left: 201.0,
                top: 560.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle72Widget(),
              ),
              Positioned(
                left: 201.0,
                top: 580.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle79Widget(),
              ),
              Positioned(
                left: 83.0,
                top: 268.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle60Widget(),
              ),
              Positioned(
                left: 84.0,
                top: 435.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle65Widget(),
              ),
              Positioned(
                left: 231.0,
                top: 268.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle62Widget(),
              ),
              Positioned(
                left: 232.0,
                top: 435.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle67Widget(),
              ),
              Positioned(
                left: 84.0,
                top: 601.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle70Widget(),
              ),
              Positioned(
                left: 231.0,
                top: 601.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle73Widget(),
              ),
              Positioned(
                left: 201.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle63Widget(),
              ),
              Positioned(
                left: 53.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle68Widget(),
              ),
              Positioned(
                left: 201.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle71Widget(),
              ),
              Positioned(
                left: 54.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 140.71603393554688,
                height: 1.0,
                child: GeneratedLine15Widget(),
              ),
              Positioned(
                left: 153.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 140.7160186767578,
                height: 1.0,
                child: GeneratedLine16Widget(),
              ),
              Positioned(
                left: 201.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine17Widget(),
              ),
              Positioned(
                left: 301.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine18Widget(),
              ),
              Positioned(
                left: 53.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine19Widget(),
              ),
              Positioned(
                left: 169.0,
                top: 288.0,
                right: null,
                bottom: null,
                width: 140.71603393554688,
                height: 1.0,
                child: GeneratedLine20Widget(),
              ),
              Positioned(
                left: 201.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine21Widget(),
              ),
              Positioned(
                left: 301.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 141.41864013671875,
                height: 1.0,
                child: GeneratedLine22Widget(),
              ),
              Positioned(
                left: 53.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine23Widget(),
              ),
              Positioned(
                left: 153.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 140.7160186767578,
                height: 1.0,
                child: GeneratedLine24Widget(),
              ),
              Positioned(
                left: 301.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 140.7160186767578,
                height: 1.0,
                child: GeneratedLine25Widget(),
              ),
              Positioned(
                left: 201.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine26Widget(),
              ),
              Positioned(
                left: 201.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle21Widget(),
              ),
              Positioned(
                left: 54.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle22Widget(),
              ),
              Positioned(
                left: 202.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle23Widget(),
              ),
              Positioned(
                left: 54.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle24Widget(),
              ),
              Positioned(
                left: 0.0,
                top: 0.0,
                right: 0.0,
                bottom: 0.0,
                width: null,
                height: null,
                child: LayoutBuilder(builder:
                    (BuildContext context, BoxConstraints constraints) {
                  double percentWidth = 0.05277777777777778;
                  double scaleX = (constraints.maxWidth * percentWidth) / 19.0;

                  double percentHeight = 0.0296875;
                  double scaleY =
                      (constraints.maxHeight * percentHeight) / 19.0;

                  return Stack(children: [
                    TransformHelper.translateAndScale(
                        translateX: constraints.maxWidth * 0.11944444444444445,
                        translateY: constraints.maxHeight * 0.0796875,
                        translateZ: 0,
                        scaleX: scaleX,
                        scaleY: scaleY,
                        scaleZ: 1,
                        child: GeneratedVectorWidget15())
                  ]);
                }),
              ),
              Positioned(
                left: 74.0,
                top: 226.0,
                right: null,
                bottom: null,
                width: 60.0,
                height: 17.0,
                child: GeneratedGEAR125Widget(),
              ),
              Positioned(
                left: 84.0,
                top: 392.0,
                right: null,
                bottom: null,
                width: 45.0,
                height: 20.0,
                child: GeneratedMT25Widget(),
              ),
              Positioned(
                left: 240.0,
                top: 393.0,
                right: null,
                bottom: null,
                width: 29.0,
                height: 20.0,
                child: GeneratedR25Widget(),
              ),
              Positioned(
                left: 213.0,
                top: 559.0,
                right: null,
                bottom: null,
                width: 79.0,
                height: 17.0,
                child: GeneratedMXKING150Widget(),
              ),
              Positioned(
                left: 87.0,
                top: 434.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget(),
              ),
              Positioned(
                left: 235.0,
                top: 434.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget1(),
              ),
              Positioned(
                left: 234.0,
                top: 600.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget2(),
              ),
              Positioned(
                left: 87.0,
                top: 600.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget3(),
              ),
              Positioned(
                left: 70.0,
                top: 413.0,
                right: null,
                bottom: null,
                width: 74.0,
                height: 20.0,
                child: Generated58725000Widget(),
              ),
              Positioned(
                left: 65.0,
                top: 578.0,
                right: null,
                bottom: null,
                width: 83.0,
                height: 20.0,
                child: Generated103000000Widget(),
              ),
              Positioned(
                left: 217.0,
                top: 412.0,
                right: null,
                bottom: null,
                width: 73.0,
                height: 20.0,
                child: Generated67760000Widget(),
              ),
              Positioned(
                left: 218.0,
                top: 579.0,
                right: null,
                bottom: null,
                width: 73.0,
                height: 20.0,
                child: Generated25180000Widget(),
              ),
              Positioned(
                left: 70.0,
                top: 246.0,
                right: null,
                bottom: null,
                width: 71.0,
                height: 20.0,
                child: Generated17735000Widget(),
              ),
              Positioned(
                left: 86.0,
                top: 267.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget4(),
              ),
              Positioned(
                left: 234.0,
                top: 267.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget5(),
              ),
              Positioned(
                left: 0.0,
                top: 0.0,
                right: 0.0,
                bottom: 0.0,
                width: null,
                height: null,
                child: LayoutBuilder(builder:
                    (BuildContext context, BoxConstraints constraints) {
                  final double width =
                      constraints.maxWidth * 0.06944444444444445;

                  final double height = constraints.maxHeight * 0.0390625;

                  return Stack(children: [
                    TransformHelper.translate(
                        x: constraints.maxWidth * 0.019444444444444445,
                        y: constraints.maxHeight * 0.0140625,
                        z: 0,
                        child: Container(
                          width: width,
                          height: height,
                          child: GeneratedGroupWidget3(),
                        ))
                  ]);
                }),
              )
            ]),
      ),
    ));
  }
}
