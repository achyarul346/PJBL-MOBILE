import 'package:flutter/material.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle77Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedLine21Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle20Widget6.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedDetailWidget30.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedLine24Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedALLNEWSATRIAFF150Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle72Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle25Widget.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedGEAR125Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedDetailWidget33.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle65Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedLine16Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedLine22Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle69Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle23Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedLine14Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedLine18Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedGSXR150Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedLine15Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/Generated28158000Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle68Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle63Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedLine23Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle79Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle64Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedLine17Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedVectorWidget30.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle75Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle17Widget6.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle22Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedGIXXERSF250Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedDetailWidget32.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle70Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedLine13Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle16Widget16.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedADDRESSFIWidget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedGSXS150Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/Generated49890000Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle59Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle18Widget6.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle67Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle16Widget17.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedProdukSuzukiWidget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle73Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle71Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle78Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedLine19Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle76Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle21Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedDetailWidget34.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle60Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle62Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle16Widget18.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedLine25Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/Generated17735000Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedLine20Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle74Widget5.dart';
import 'package:flutterapp/helpers/transform/transform.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle61Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/Generated30511000Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedRectangle66Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedGroupWidget8.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedDetailWidget35.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/Generated34231000Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedDetailWidget31.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/GeneratedLine26Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedproduksuzukiwidget1/generated/Generated18913000Widget1.dart';

/* Frame produk suzuki
    Autogenerated by FlutLab FTF Generator
  */
class GeneratedProduksuzukiWidget1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Material(
        child: ClipRRect(
      borderRadius: BorderRadius.circular(20.0),
      child: Container(
        width: 360.0,
        height: 640.0,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20.0),
        ),
        child: Stack(
            fit: StackFit.expand,
            alignment: Alignment.center,
            overflow: Overflow.visible,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(20.0),
                child: Container(
                  color: Color.fromARGB(255, 255, 255, 255),
                ),
              ),
              Positioned(
                left: 30.0,
                top: 39.0,
                right: null,
                bottom: null,
                width: 320.0,
                height: 42.0,
                child: GeneratedRectangle16Widget16(),
              ),
              Positioned(
                left: 35.0,
                top: 15.0,
                right: null,
                bottom: null,
                width: 35.0,
                height: 31.0,
                child: GeneratedRectangle16Widget17(),
              ),
              Positioned(
                left: 36.0,
                top: 15.0,
                right: null,
                bottom: null,
                width: 46.754676818847656,
                height: 1.0,
                child: GeneratedLine13Widget5(),
              ),
              Positioned(
                left: 70.0,
                top: 15.0,
                right: null,
                bottom: null,
                width: 46.754676818847656,
                height: 1.0,
                child: GeneratedLine14Widget5(),
              ),
              Positioned(
                left: 53.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle16Widget18(),
              ),
              Positioned(
                left: 53.0,
                top: 90.0,
                right: null,
                bottom: null,
                width: 179.0,
                height: 32.0,
                child: GeneratedProdukSuzukiWidget1(),
              ),
              Positioned(
                left: 201.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle17Widget6(),
              ),
              Positioned(
                left: 53.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle18Widget6(),
              ),
              Positioned(
                left: 53.0,
                top: 227.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle59Widget5(),
              ),
              Positioned(
                left: 53.0,
                top: 247.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle74Widget5(),
              ),
              Positioned(
                left: 53.0,
                top: 394.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle64Widget5(),
              ),
              Positioned(
                left: 54.0,
                top: 414.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle76Widget5(),
              ),
              Positioned(
                left: 201.0,
                top: 227.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle61Widget5(),
              ),
              Positioned(
                left: 201.0,
                top: 247.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle75Widget5(),
              ),
              Positioned(
                left: 201.0,
                top: 394.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle66Widget5(),
              ),
              Positioned(
                left: 201.0,
                top: 414.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle77Widget5(),
              ),
              Positioned(
                left: 53.0,
                top: 560.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle69Widget5(),
              ),
              Positioned(
                left: 54.0,
                top: 580.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle78Widget5(),
              ),
              Positioned(
                left: 201.0,
                top: 560.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle72Widget5(),
              ),
              Positioned(
                left: 201.0,
                top: 580.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle79Widget5(),
              ),
              Positioned(
                left: 83.0,
                top: 268.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle60Widget5(),
              ),
              Positioned(
                left: 84.0,
                top: 435.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle65Widget5(),
              ),
              Positioned(
                left: 231.0,
                top: 268.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle62Widget5(),
              ),
              Positioned(
                left: 232.0,
                top: 435.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle67Widget5(),
              ),
              Positioned(
                left: 84.0,
                top: 601.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle70Widget5(),
              ),
              Positioned(
                left: 231.0,
                top: 601.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle73Widget5(),
              ),
              Positioned(
                left: 201.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle63Widget5(),
              ),
              Positioned(
                left: 53.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle68Widget5(),
              ),
              Positioned(
                left: 201.0,
                top: 456.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle71Widget5(),
              ),
              Positioned(
                left: 54.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 140.71603393554688,
                height: 1.0,
                child: GeneratedLine15Widget5(),
              ),
              Positioned(
                left: 153.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 140.7160186767578,
                height: 1.0,
                child: GeneratedLine16Widget5(),
              ),
              Positioned(
                left: 201.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine17Widget5(),
              ),
              Positioned(
                left: 301.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine18Widget5(),
              ),
              Positioned(
                left: 53.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine19Widget5(),
              ),
              Positioned(
                left: 169.0,
                top: 288.0,
                right: null,
                bottom: null,
                width: 140.71603393554688,
                height: 1.0,
                child: GeneratedLine20Widget5(),
              ),
              Positioned(
                left: 201.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine21Widget5(),
              ),
              Positioned(
                left: 301.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 141.41864013671875,
                height: 1.0,
                child: GeneratedLine22Widget5(),
              ),
              Positioned(
                left: 53.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine23Widget5(),
              ),
              Positioned(
                left: 153.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 140.7160186767578,
                height: 1.0,
                child: GeneratedLine24Widget5(),
              ),
              Positioned(
                left: 301.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 140.7160186767578,
                height: 1.0,
                child: GeneratedLine25Widget5(),
              ),
              Positioned(
                left: 201.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine26Widget5(),
              ),
              Positioned(
                left: 0.0,
                top: 0.0,
                right: 0.0,
                bottom: 0.0,
                width: null,
                height: null,
                child: LayoutBuilder(builder:
                    (BuildContext context, BoxConstraints constraints) {
                  double percentWidth = 0.05277777777777778;
                  double scaleX = (constraints.maxWidth * percentWidth) / 19.0;

                  double percentHeight = 0.0296875;
                  double scaleY =
                      (constraints.maxHeight * percentHeight) / 19.0;

                  return Stack(children: [
                    TransformHelper.translateAndScale(
                        translateX: constraints.maxWidth * 0.15,
                        translateY: constraints.maxHeight * 0.078125,
                        translateZ: 0,
                        scaleX: scaleX,
                        scaleY: scaleY,
                        scaleZ: 1,
                        child: GeneratedVectorWidget30())
                  ]);
                }),
              ),
              Positioned(
                left: 54.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle20Widget6(),
              ),
              Positioned(
                left: 202.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle21Widget3(),
              ),
              Positioned(
                left: 54.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle22Widget3(),
              ),
              Positioned(
                left: 201.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle23Widget5(),
              ),
              Positioned(
                left: 215.0,
                top: 559.0,
                right: null,
                bottom: null,
                width: 73.0,
                height: 17.0,
                child: GeneratedADDRESSFIWidget1(),
              ),
              Positioned(
                left: 234.0,
                top: 600.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget30(),
              ),
              Positioned(
                left: 87.0,
                top: 600.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget31(),
              ),
              Positioned(
                left: 218.0,
                top: 579.0,
                right: null,
                bottom: null,
                width: 72.0,
                height: 20.0,
                child: Generated18913000Widget1(),
              ),
              Positioned(
                left: 69.0,
                top: 579.0,
                right: null,
                bottom: null,
                width: 76.0,
                height: 20.0,
                child: Generated49890000Widget1(),
              ),
              Positioned(
                left: 75.0,
                top: 225.0,
                right: null,
                bottom: null,
                width: 60.0,
                height: 17.0,
                child: GeneratedGEAR125Widget3(),
              ),
              Positioned(
                left: 205.0,
                top: 228.0,
                right: null,
                bottom: null,
                width: 95.0,
                height: 12.0,
                child: GeneratedALLNEWSATRIAFF150Widget1(),
              ),
              Positioned(
                left: 71.0,
                top: 246.0,
                right: null,
                bottom: null,
                width: 71.0,
                height: 20.0,
                child: Generated17735000Widget3(),
              ),
              Positioned(
                left: 218.0,
                top: 246.0,
                right: null,
                bottom: null,
                width: 73.0,
                height: 20.0,
                child: Generated28158000Widget1(),
              ),
              Positioned(
                left: 86.0,
                top: 267.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget32(),
              ),
              Positioned(
                left: 234.0,
                top: 267.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget33(),
              ),
              Positioned(
                left: 73.0,
                top: 393.0,
                right: null,
                bottom: null,
                width: 66.0,
                height: 20.0,
                child: GeneratedGSXS150Widget1(),
              ),
              Positioned(
                left: 59.0,
                top: 559.0,
                right: null,
                bottom: null,
                width: 89.0,
                height: 17.0,
                child: GeneratedGIXXERSF250Widget1(),
              ),
              Positioned(
                left: 220.0,
                top: 393.0,
                right: null,
                bottom: null,
                width: 66.0,
                height: 20.0,
                child: GeneratedGSXR150Widget1(),
              ),
              Positioned(
                left: 70.0,
                top: 414.0,
                right: null,
                bottom: null,
                width: 72.0,
                height: 20.0,
                child: Generated30511000Widget1(),
              ),
              Positioned(
                left: 216.0,
                top: 413.0,
                right: null,
                bottom: null,
                width: 74.0,
                height: 20.0,
                child: Generated34231000Widget1(),
              ),
              Positioned(
                left: 86.0,
                top: 434.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget34(),
              ),
              Positioned(
                left: 234.0,
                top: 434.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget35(),
              ),
              Positioned(
                left: 0.0,
                top: 0.0,
                right: 0.0,
                bottom: 0.0,
                width: null,
                height: null,
                child: LayoutBuilder(builder:
                    (BuildContext context, BoxConstraints constraints) {
                  final double width =
                      constraints.maxWidth * 0.06944444444444445;

                  final double height = constraints.maxHeight * 0.0390625;

                  return Stack(children: [
                    TransformHelper.translate(
                        x: constraints.maxWidth * 0.013888888888888888,
                        y: constraints.maxHeight * 0.021875,
                        z: 0,
                        child: Container(
                          width: width,
                          height: height,
                          child: GeneratedGroupWidget8(),
                        ))
                  ]);
                }),
              ),
              Positioned(
                left: 54.0,
                top: 456.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle25Widget(),
              )
            ]),
      ),
    ));
  }
}
