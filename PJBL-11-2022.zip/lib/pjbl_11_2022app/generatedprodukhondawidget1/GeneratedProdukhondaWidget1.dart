import 'package:flutter/material.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle61Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle67Widget3.dart';
import 'package:flutterapp/helpers/transform/transform.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle80Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedDetailWidget18.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedLine25Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedLine19Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedLine20Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle23Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle66Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/Generated63000000Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle64Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle71Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle68Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedLine17Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle59Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedLine22Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle60Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedLine26Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedHONDASCOOPYWidget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedDetailWidget22.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/Generated25000000Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedLine15Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle16Widget10.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedHONDABEATWidget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/Generated24637000Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle20Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle80Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedDetailWidget23.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle80Widget5.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle16Widget12.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle78Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/Generated19000000Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle65Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle76Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedGTR150Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedLine21Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle79Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle63Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle74Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedHONDACBR250RRWidget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedDetailWidget19.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedDetailWidget20.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle77Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle70Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedProdukHondaWidget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle75Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedHONDAVARIO160Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedDetailWidget21.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedVectorWidget24.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle73Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle16Widget11.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle81Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle69Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/Generated20320000Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedHONDAPCXWidget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle72Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedLine14Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedGroupWidget6.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/Generated29000000Widget1.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle18Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle62Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedLine18Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedLine24Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedLine23Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedRectangle17Widget4.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedLine16Widget3.dart';
import 'package:flutterapp/pjbl_11_2022app/generatedprodukhondawidget1/generated/GeneratedLine13Widget3.dart';

/* Frame produk honda
    Autogenerated by FlutLab FTF Generator
  */
class GeneratedProdukhondaWidget1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Material(
        child: ClipRRect(
      borderRadius: BorderRadius.circular(20.0),
      child: Container(
        width: 360.0,
        height: 640.0,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20.0),
        ),
        child: Stack(
            fit: StackFit.expand,
            alignment: Alignment.center,
            overflow: Overflow.visible,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(20.0),
                child: Container(
                  color: Color.fromARGB(255, 255, 255, 255),
                ),
              ),
              Positioned(
                left: 20.0,
                top: 40.0,
                right: null,
                bottom: null,
                width: 320.0,
                height: 42.0,
                child: GeneratedRectangle16Widget10(),
              ),
              Positioned(
                left: 35.0,
                top: 15.0,
                right: null,
                bottom: null,
                width: 35.0,
                height: 31.0,
                child: GeneratedRectangle16Widget11(),
              ),
              Positioned(
                left: 36.0,
                top: 15.0,
                right: null,
                bottom: null,
                width: 46.754676818847656,
                height: 1.0,
                child: GeneratedLine13Widget3(),
              ),
              Positioned(
                left: 70.0,
                top: 15.0,
                right: null,
                bottom: null,
                width: 46.754676818847656,
                height: 1.0,
                child: GeneratedLine14Widget3(),
              ),
              Positioned(
                left: 53.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle16Widget12(),
              ),
              Positioned(
                left: 54.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle20Widget4(),
              ),
              Positioned(
                left: 53.0,
                top: 90.0,
                right: null,
                bottom: null,
                width: 175.0,
                height: 32.0,
                child: GeneratedProdukHondaWidget1(),
              ),
              Positioned(
                left: 201.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle17Widget4(),
              ),
              Positioned(
                left: 53.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle18Widget4(),
              ),
              Positioned(
                left: 53.0,
                top: 227.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle59Widget3(),
              ),
              Positioned(
                left: 53.0,
                top: 247.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle74Widget3(),
              ),
              Positioned(
                left: 53.0,
                top: 394.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle64Widget3(),
              ),
              Positioned(
                left: 54.0,
                top: 414.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle76Widget3(),
              ),
              Positioned(
                left: 201.0,
                top: 227.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle61Widget3(),
              ),
              Positioned(
                left: 201.0,
                top: 247.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle75Widget3(),
              ),
              Positioned(
                left: 201.0,
                top: 394.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle66Widget3(),
              ),
              Positioned(
                left: 201.0,
                top: 414.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle77Widget3(),
              ),
              Positioned(
                left: 53.0,
                top: 560.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle69Widget3(),
              ),
              Positioned(
                left: 54.0,
                top: 580.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle78Widget3(),
              ),
              Positioned(
                left: 201.0,
                top: 560.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle72Widget3(),
              ),
              Positioned(
                left: 201.0,
                top: 580.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 13.0,
                child: GeneratedRectangle79Widget3(),
              ),
              Positioned(
                left: 83.0,
                top: 268.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle60Widget3(),
              ),
              Positioned(
                left: 84.0,
                top: 435.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle65Widget3(),
              ),
              Positioned(
                left: 231.0,
                top: 268.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle62Widget3(),
              ),
              Positioned(
                left: 232.0,
                top: 435.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle67Widget3(),
              ),
              Positioned(
                left: 84.0,
                top: 601.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle70Widget3(),
              ),
              Positioned(
                left: 231.0,
                top: 601.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 13.0,
                child: GeneratedRectangle73Widget3(),
              ),
              Positioned(
                left: 201.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle63Widget3(),
              ),
              Positioned(
                left: 53.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle68Widget3(),
              ),
              Positioned(
                left: 201.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle71Widget3(),
              ),
              Positioned(
                left: 54.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 140.71603393554688,
                height: 1.0,
                child: GeneratedLine15Widget3(),
              ),
              Positioned(
                left: 153.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 140.7160186767578,
                height: 1.0,
                child: GeneratedLine16Widget3(),
              ),
              Positioned(
                left: 201.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine17Widget3(),
              ),
              Positioned(
                left: 301.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine18Widget3(),
              ),
              Positioned(
                left: 53.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine19Widget3(),
              ),
              Positioned(
                left: 169.0,
                top: 288.0,
                right: null,
                bottom: null,
                width: 140.71603393554688,
                height: 1.0,
                child: GeneratedLine20Widget3(),
              ),
              Positioned(
                left: 201.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine21Widget3(),
              ),
              Positioned(
                left: 301.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 141.41864013671875,
                height: 1.0,
                child: GeneratedLine22Widget3(),
              ),
              Positioned(
                left: 53.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine23Widget3(),
              ),
              Positioned(
                left: 153.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 140.7160186767578,
                height: 1.0,
                child: GeneratedLine24Widget3(),
              ),
              Positioned(
                left: 301.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 140.7160186767578,
                height: 1.0,
                child: GeneratedLine25Widget3(),
              ),
              Positioned(
                left: 201.0,
                top: 453.0,
                right: null,
                bottom: null,
                width: 141.42135620117188,
                height: 1.0,
                child: GeneratedLine26Widget3(),
              ),
              Positioned(
                left: 0.0,
                top: 0.0,
                right: 0.0,
                bottom: 0.0,
                width: null,
                height: null,
                child: LayoutBuilder(builder:
                    (BuildContext context, BoxConstraints constraints) {
                  double percentWidth = 0.05277777777777778;
                  double scaleX = (constraints.maxWidth * percentWidth) / 19.0;

                  double percentHeight = 0.0296875;
                  double scaleY =
                      (constraints.maxHeight * percentHeight) / 19.0;

                  return Stack(children: [
                    TransformHelper.translateAndScale(
                        translateX: constraints.maxWidth * 0.11944444444444445,
                        translateY: constraints.maxHeight * 0.0796875,
                        translateZ: 0,
                        scaleX: scaleX,
                        scaleY: scaleY,
                        scaleZ: 1,
                        child: GeneratedVectorWidget24())
                  ]);
                }),
              ),
              Positioned(
                left: 55.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle80Widget3(),
              ),
              Positioned(
                left: 202.0,
                top: 120.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle81Widget1(),
              ),
              Positioned(
                left: 55.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle80Widget4(),
              ),
              Positioned(
                left: 202.0,
                top: 287.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle23Widget3(),
              ),
              Positioned(
                left: 53.0,
                top: 454.0,
                right: null,
                bottom: null,
                width: 100.0,
                height: 100.0,
                child: GeneratedRectangle80Widget5(),
              ),
              Positioned(
                left: 226.0,
                top: 559.0,
                right: null,
                bottom: null,
                width: 52.0,
                height: 17.0,
                child: GeneratedGTR150Widget1(),
              ),
              Positioned(
                left: 68.0,
                top: 226.0,
                right: null,
                bottom: null,
                width: 75.0,
                height: 17.0,
                child: GeneratedHONDAPCXWidget1(),
              ),
              Positioned(
                left: 68.0,
                top: 396.0,
                right: null,
                bottom: null,
                width: 75.0,
                height: 12.0,
                child: GeneratedHONDAVARIO160Widget1(),
              ),
              Positioned(
                left: 68.0,
                top: 413.0,
                right: null,
                bottom: null,
                width: 76.0,
                height: 20.0,
                child: Generated29000000Widget1(),
              ),
              Positioned(
                left: 216.0,
                top: 579.0,
                right: null,
                bottom: null,
                width: 74.0,
                height: 20.0,
                child: Generated24637000Widget1(),
              ),
              Positioned(
                left: 233.0,
                top: 600.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget18(),
              ),
              Positioned(
                left: 69.0,
                top: 246.0,
                right: null,
                bottom: null,
                width: 76.0,
                height: 20.0,
                child: Generated25000000Widget1(),
              ),
              Positioned(
                left: 86.0,
                top: 266.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget19(),
              ),
              Positioned(
                left: 87.0,
                top: 434.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget20(),
              ),
              Positioned(
                left: 235.0,
                top: 434.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget21(),
              ),
              Positioned(
                left: 234.0,
                top: 266.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget22(),
              ),
              Positioned(
                left: 212.0,
                top: 226.0,
                right: null,
                bottom: null,
                width: 81.0,
                height: 17.0,
                child: GeneratedHONDABEATWidget1(),
              ),
              Positioned(
                left: 217.0,
                top: 246.0,
                right: null,
                bottom: null,
                width: 75.0,
                height: 20.0,
                child: Generated19000000Widget1(),
              ),
              Positioned(
                left: 209.0,
                top: 393.0,
                right: null,
                bottom: null,
                width: 85.0,
                height: 14.0,
                child: GeneratedHONDASCOOPYWidget1(),
              ),
              Positioned(
                left: 216.0,
                top: 413.0,
                right: null,
                bottom: null,
                width: 76.0,
                height: 20.0,
                child: Generated20320000Widget1(),
              ),
              Positioned(
                left: 56.0,
                top: 560.0,
                right: null,
                bottom: null,
                width: 95.0,
                height: 14.0,
                child: GeneratedHONDACBR250RRWidget1(),
              ),
              Positioned(
                left: 67.0,
                top: 579.0,
                right: null,
                bottom: null,
                width: 77.0,
                height: 20.0,
                child: Generated63000000Widget1(),
              ),
              Positioned(
                left: 86.0,
                top: 600.0,
                right: null,
                bottom: null,
                width: 40.0,
                height: 20.0,
                child: GeneratedDetailWidget23(),
              ),
              Positioned(
                left: 0.0,
                top: 0.0,
                right: 0.0,
                bottom: 0.0,
                width: null,
                height: null,
                child: LayoutBuilder(builder:
                    (BuildContext context, BoxConstraints constraints) {
                  final double width =
                      constraints.maxWidth * 0.06944444444444445;

                  final double height = constraints.maxHeight * 0.0390625;

                  return Stack(children: [
                    TransformHelper.translate(
                        x: constraints.maxWidth * 0.019444444444444445,
                        y: constraints.maxHeight * 0.0109375,
                        z: 0,
                        child: Container(
                          width: width,
                          height: height,
                          child: GeneratedGroupWidget6(),
                        ))
                  ]);
                }),
              )
            ]),
      ),
    ));
  }
}
